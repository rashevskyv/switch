1. Синхронизируй joy-con'ы с sysnand
   Pair joy-cons to sysnand


2. Скинь папки из архива в корень карты памяти
   Drop folders to sd


3. Вставь карту в switch и зайди в hekate
   Put sd to switch and run hekate


4. Запусти TegraExplorer.bin из вкладки "payloads"
   Run TegraExplorer.bin from "payloads"


5. Перейди по пути [SD:/] SD CARD -> tegraeplorer -> syncfix -> Syncfix.te -> Launch Script
   Go to [SD:/] SD CARD -> tegraeplorer -> syncfix -> Syncfix v2.te -> Launch Script


Sourse: https://gbatemp.net/threads/guide-pairing-the-joy-con-on-emunand-and-sysnand.562519/